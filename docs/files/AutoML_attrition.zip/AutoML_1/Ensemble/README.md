# Summary of Ensemble

[<< Go back](../README.md)


## Ensemble structure
| Model             |   Weight |
|:------------------|---------:|
| 3_Linear          |        5 |
| 4_Default_Xgboost |        1 |

## Metric details
|           |    score |     threshold |
|:----------|---------:|--------------:|
| logloss   | 0.179811 | nan           |
| auc       | 0.940623 | nan           |
| f1        | 0.722222 |   0.363999    |
| accuracy  | 0.936508 |   0.363999    |
| precision | 0.84     |   0.508587    |
| recall    | 1        |   0.000453364 |
| mcc       | 0.687858 |   0.363999    |


## Metric details with threshold from accuracy metric
|           |    score |   threshold |
|:----------|---------:|------------:|
| logloss   | 0.179811 |  nan        |
| auc       | 0.940623 |  nan        |
| f1        | 0.722222 |    0.363999 |
| accuracy  | 0.936508 |    0.363999 |
| precision | 0.764706 |    0.363999 |
| recall    | 0.684211 |    0.363999 |
| mcc       | 0.687858 |    0.363999 |


## Confusion matrix (at threshold=0.363999)
|                |   Predicted as No |   Predicted as Yes |
|:---------------|------------------:|-------------------:|
| Labeled as No  |               269 |                  8 |
| Labeled as Yes |                12 |                 26 |

## Learning curves
![Learning curves](learning_curves.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Kolmogorov-Smirnov Statistic

![Kolmogorov-Smirnov Statistic](ks_statistic.png)


## Precision-Recall Curve

![Precision-Recall Curve](precision_recall_curve.png)


## Calibration Curve

![Calibration Curve](calibration_curve_curve.png)


## Cumulative Gains Curve

![Cumulative Gains Curve](cumulative_gains_curve.png)


## Lift Curve

![Lift Curve](lift_curve.png)



[<< Go back](../README.md)
