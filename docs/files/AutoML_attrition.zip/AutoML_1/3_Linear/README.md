# Summary of 3_Linear

[<< Go back](../README.md)


## Logistic Regression (Linear)
- **n_jobs**: -1
- **explain_level**: 2

## Validation
 - **validation_type**: split
 - **train_ratio**: 0.75
 - **shuffle**: True
 - **stratify**: True

## Optimized metric
logloss

## Training time

5.0 seconds

## Metric details
|           |    score |     threshold |
|:----------|---------:|--------------:|
| logloss   | 0.180732 | nan           |
| auc       | 0.941288 | nan           |
| f1        | 0.72973  |   0.367506    |
| accuracy  | 0.936508 |   0.427194    |
| precision | 0.8      |   0.427194    |
| recall    | 1        |   4.26235e-08 |
| mcc       | 0.694114 |   0.367506    |


## Metric details with threshold from accuracy metric
|           |    score |   threshold |
|:----------|---------:|------------:|
| logloss   | 0.180732 |  nan        |
| auc       | 0.941288 |  nan        |
| f1        | 0.705882 |    0.427194 |
| accuracy  | 0.936508 |    0.427194 |
| precision | 0.8      |    0.427194 |
| recall    | 0.631579 |    0.427194 |
| mcc       | 0.676738 |    0.427194 |


## Confusion matrix (at threshold=0.427194)
|                |   Predicted as No |   Predicted as Yes |
|:---------------|------------------:|-------------------:|
| Labeled as No  |               271 |                  6 |
| Labeled as Yes |                14 |                 24 |

## Learning curves
![Learning curves](learning_curves.png)

## Coefficients
| feature                  |   Learner_1 |
|:-------------------------|------------:|
| OverTime                 |  1.59634    |
| YearsSinceLastPromotion  |  0.976581   |
| NumCompaniesWorked       |  0.676348   |
| MaritalStatus            |  0.60668    |
| DistanceFromHome         |  0.552412   |
| YearsAtCompany           |  0.226671   |
| JobLevel                 |  0.0503342  |
| PercentSalaryHike        |  0.0211757  |
| Education                |  0.0160198  |
| MonthlyRate              |  0.00445888 |
| RelationshipSatisfaction | -0.053822   |
| PerformanceRating        | -0.088827   |
| HourlyRate               | -0.0889959  |
| EmployeeID               | -0.105433   |
| Gender                   | -0.112682   |
| DailyRate                | -0.209171   |
| BusinessTravel           | -0.227198   |
| TrainingTimesLastYear    | -0.243398   |
| EducationField           | -0.255347   |
| JobRole                  | -0.288887   |
| Department               | -0.290652   |
| Shift                    | -0.320885   |
| EnvironmentSatisfaction  | -0.404948   |
| WorkLifeBalance          | -0.532647   |
| JobSatisfaction          | -0.571426   |
| JobInvolvement           | -0.659634   |
| Age                      | -0.724101   |
| YearsInCurrentRole       | -0.72668    |
| YearsWithCurrManager     | -0.758168   |
| TotalWorkingYears        | -0.825299   |
| MonthlyIncome            | -1.24511    |
| intercept                | -4.66817    |


## Permutation-based Importance
![Permutation-based Importance](permutation_importance.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Kolmogorov-Smirnov Statistic

![Kolmogorov-Smirnov Statistic](ks_statistic.png)


## Precision-Recall Curve

![Precision-Recall Curve](precision_recall_curve.png)


## Calibration Curve

![Calibration Curve](calibration_curve_curve.png)


## Cumulative Gains Curve

![Cumulative Gains Curve](cumulative_gains_curve.png)


## Lift Curve

![Lift Curve](lift_curve.png)



## SHAP Importance
![SHAP Importance](shap_importance.png)

## SHAP Dependence plots

### Dependence (Fold 1)
![SHAP Dependence from Fold 1](learner_fold_0_shap_dependence.png)

## SHAP Decision plots

### Top-10 Worst decisions for class 0 (Fold 1)
![SHAP worst decisions class 0 from Fold 1](learner_fold_0_shap_class_0_worst_decisions.png)
### Top-10 Best decisions for class 0 (Fold 1)
![SHAP best decisions class 0 from Fold 1](learner_fold_0_shap_class_0_best_decisions.png)
### Top-10 Worst decisions for class 1 (Fold 1)
![SHAP worst decisions class 1 from Fold 1](learner_fold_0_shap_class_1_worst_decisions.png)
### Top-10 Best decisions for class 1 (Fold 1)
![SHAP best decisions class 1 from Fold 1](learner_fold_0_shap_class_1_best_decisions.png)

[<< Go back](../README.md)
